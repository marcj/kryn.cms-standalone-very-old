Hello, <?php echo $name ?>
