
/**
 * Current locale
 * @var        string
 */
protected $currentLocale = '<?php echo $defaultLocale ?>';

/**
 * Current translation objects
 * @var        array[<?php echo $objectClassname ?>]
 */
protected $currentTranslations;
